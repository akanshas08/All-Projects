package com.mgnrega.exceptions;

public class BDOException extends Exception{
	
public BDOException() {
		
	}
	
	public BDOException(String message) {
		super(message);
	}

}
